#include <lpc13xx.h>

void delay(void);

unsigned int i;

void lcd_int(void);
void dat(unsigned char);
void cmd(unsigned char);
void string(unsigned char *);


int main(void)
{
	
	
	LPC_GPIO0->DIR = 0xFFFF;
	LPC_GPIO3->DIR = 0xFFFF;
    lcd_int();
    cmd(0xC0);
    string("Hello World");
	
	LPC_GPIO1->DIR |= (1<<4); //Config PIO1_4,PIO1_5,PIO1_6,PIO1_7 as Output pins given to LED's
	LPC_GPIO1->DIR |= (1<<5);
LPC_GPIO1->DIR |= (1<<6);
LPC_GPIO1->DIR |= (1<<7);  	
	LPC_GPIO0->DIR &= ~((1<<9));
//Configure PIO1_8 and PIO0_9 as Input pins

	while(1)
	{
		if((!(LPC_GPIO1->DATA & (1<<8))) && (!(LPC_GPIO0->DATA & (1<<9)))){
			
			  cmd(0x1C);
        delay();
			
			LPC_GPIO1->DATA = 0x000; 
			delay();
			
			LPC_GPIO1->DATA = 0x010; 
			delay();
	
		LPC_GPIO1->DATA = 0x020; 
			delay();
	
			LPC_GPIO1->DATA = 0x030; 
			delay();
		
			LPC_GPIO1->DATA = 0x040; 
			delay();
		
			LPC_GPIO1->DATA = 0x050; 
			delay();

			LPC_GPIO1->DATA = 0x060; 
			delay();
			
			LPC_GPIO1->DATA = 0x070; 
			delay();

			LPC_GPIO1->DATA = 0x080;
			delay();

			LPC_GPIO1->DATA = 0x090; 
			delay();

			LPC_GPIO1->DATA = 0x0A0; 
			delay();

			LPC_GPIO1->DATA = 0x0B0; 
			delay();

			LPC_GPIO1->DATA = 0x0C0; 
			delay();

			LPC_GPIO1->DATA = 0x0D0; 
			delay();

			LPC_GPIO1->DATA = 0x0E0; 
			delay();

			LPC_GPIO1->DATA = 0x0F0; 
			delay();
		}

	if((!(LPC_GPIO0->DATA & (1<<9))) && (LPC_GPIO1->DATA & (1<<8))){
		
        cmd(0x1C);
        delay();
}
	
	if(((LPC_GPIO0->DATA & (1<<9))) && (!(LPC_GPIO1->DATA & (1<<8)))){
		
       LPC_GPIO1->DATA = 0x000; 
			delay();
			
			LPC_GPIO1->DATA = 0x010; 
			delay();
	
		LPC_GPIO1->DATA = 0x020; 
			delay();
	
			LPC_GPIO1->DATA = 0x030; 
			delay();
		
			LPC_GPIO1->DATA = 0x040; 
			delay();
		
			LPC_GPIO1->DATA = 0x050; 
			delay();

			LPC_GPIO1->DATA = 0x060; 
			delay();
			
			LPC_GPIO1->DATA = 0x070; 
			delay();

			LPC_GPIO1->DATA = 0x080;
			delay();

			LPC_GPIO1->DATA = 0x090; 
			delay();

			LPC_GPIO1->DATA = 0x0A0; 
			delay();

			LPC_GPIO1->DATA = 0x0B0; 
			delay();

			LPC_GPIO1->DATA = 0x0C0; 
			delay();

			LPC_GPIO1->DATA = 0x0D0; 
			delay();

			LPC_GPIO1->DATA = 0x0E0; 
			delay();

			LPC_GPIO1->DATA = 0x0F0; 
			delay(); 
}

	}
	return 0;
}

void lcd_int(void)
{
cmd(0x38);
cmd(0x0c);
cmd(0x06);
cmd(0x01);
cmd(0x80);
}
void cmd(unsigned char a)
{
LPC_GPIO0->DATA = 0x00;
LPC_GPIO0->DATA|=(a<<1);
LPC_GPIO3->DATA &= ~(1<<0);//rs=0
LPC_GPIO3->DATA &= ~(1<<1);//rw=0
LPC_GPIO3->DATA|=(1<<2);
delay();
LPC_GPIO3->DATA &= ~(1<<2);
}
void dat(unsigned char b)
{
LPC_GPIO0->DATA = 0x00;
LPC_GPIO0->DATA|=(b<<1);
LPC_GPIO3->DATA |= (1<<0);//rs=1
LPC_GPIO3->DATA &= ~(1<<1); //rw=0
LPC_GPIO3->DATA|=(1<<2); //en=1
delay();
LPC_GPIO3->DATA &= ~(1<<2);//en=0
}

void string(unsigned char *p)
{
while(*p!='\0') {
dat(*p++);
}
}

void delay(void) //Hard-coded delay function
{
	int count,i=0;
	for(count=0; count < 50000; count++) //You can edit this as per your needs
	{
		i++; //something needs to be here else compiler will remove the for loop!
	}
}


